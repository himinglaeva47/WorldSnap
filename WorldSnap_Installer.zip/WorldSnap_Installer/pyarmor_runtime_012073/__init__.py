# Pyarmor 9.2.4 (basic), 012073, 2026-04-03T15:52:07.132989
from .pyarmor_runtime import __pyarmor__
