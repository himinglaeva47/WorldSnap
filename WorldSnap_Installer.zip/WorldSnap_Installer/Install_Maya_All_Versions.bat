@echo off
setlocal EnableExtensions

echo.
echo ===== WorldSnap Installer =====
echo.

set "BASE_DIR=%~dp0"
set "USER_MAYA=%USERPROFILE%\Documents\maya"

call :Install 2024
call :Install 2025
call :Install 2026

echo.
echo ===== Done =====
echo.
pause
exit /b

:Install
set "VER=%~1"
set "SRC=%BASE_DIR%Maya_%VER%\modules"
set "DST=%USER_MAYA%\%VER%\modules"

echo -----------------------------------
echo Maya %VER%
echo SRC: %SRC%
echo DST: %DST%
echo -----------------------------------

if not exist "%SRC%" (
    echo Source modules folder not found. Skipping %VER%.
    echo.
    goto :eof
)

if not exist "%USER_MAYA%\%VER%" (
    echo Maya version folder not found. Skipping %VER%.
    echo.
    goto :eof
)

if not exist "%DST%" mkdir "%DST%"

xcopy "%SRC%\*" "%DST%\" /E /I /Y

echo Finished Maya %VER%
echo.
goto :eof