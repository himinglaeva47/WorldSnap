import importlib
from worldsnap import installer
importlib.reload(installer)
installer.install()