# worldsnap/installer.py
# Maya 2023 shelf + icon installer for WorldSnap (package name: worldsnap)

import os
import shutil

import maya.cmds as cmds
import maya.mel as mel
import maya.utils as utils

SHELF_LABEL = "WorldSnap"
BUTTON_LABEL = "WorldSnap"
BUTTON_ANN = "WorldSnap"

ICON_FILE = "worldsnap.png"
FALLBACK_ICON = "commandButton.png"

OPT_INSTALLED = "worldsnap_shelf_installed_v1"


def _g_shelf_top_level():
    try:
        return mel.eval("$tmp = $gShelfTopLevel")
    except Exception:
        return ""


def _shelf_ui_ready():
    g = _g_shelf_top_level()
    if not g:
        return False
    try:
        return cmds.control(g, exists=True)
    except Exception:
        return False


def _package_dir():
    return os.path.dirname(os.path.abspath(__file__))


def _prefs_icons_dir():
    d = cmds.internalVar(userBitmapsDir=True)  # .../prefs/icons/
    try:
        os.makedirs(d, exist_ok=True)
    except Exception:
        pass
    return d


def _refresh_icon_cache_quiet():
    try:
        cmds.refreshIconCache()
    except Exception:
        pass


def _ensure_icon_in_prefs():
    """
    Copy worldsnap.png from package folder into prefs/icons (best Maya 2023 reliability).
    Return filename Maya should use (NOT full path).
    """
    dst_dir = _prefs_icons_dir()
    dst = os.path.join(dst_dir, ICON_FILE)

    if os.path.exists(dst):
        return ICON_FILE

    src = os.path.join(_package_dir(), ICON_FILE)
    if os.path.exists(src):
        try:
            shutil.copy2(src, dst)
            return ICON_FILE
        except Exception:
            pass

    return FALLBACK_ICON


def _worldsnap_command():
    return (
        "import importlib\n"
        "from worldsnap import worldsnap\n"
        "importlib.reload(worldsnap)\n"
        "worldsnap.show_ui()\n"
    )


def _ensure_shelf():
    g = _g_shelf_top_level()
    shelves = cmds.tabLayout(g, q=True, childArray=True) or []

    for sh in shelves:
        try:
            if sh == SHELF_LABEL:
                return sh
            if cmds.shelfLayout(sh, q=True, label=True) == SHELF_LABEL:
                return sh
        except Exception:
            pass

    new_shelf = cmds.shelfLayout(SHELF_LABEL, parent=g)
    try:
        cmds.shelfLayout(new_shelf, e=True, label=SHELF_LABEL)
    except Exception:
        pass
    return new_shelf


def _find_worldsnap_buttons(shelf_layout):
    found = []
    kids = cmds.shelfLayout(shelf_layout, q=True, childArray=True) or []
    for k in kids:
        try:
            if cmds.objectTypeUI(k) != "shelfButton":
                continue
            ann = cmds.shelfButton(k, q=True, ann=True) or ""
            cmd = cmds.shelfButton(k, q=True, command=True) or ""
            if ann == BUTTON_ANN or "from worldsnap import worldsnap" in cmd or "worldsnap.show_ui" in cmd:
                found.append(k)
        except Exception:
            pass
    return found


def _dedupe_keep_first(buttons):
    if not buttons:
        return None
    keep = buttons[0]
    for b in buttons[1:]:
        try:
            cmds.deleteUI(b)
        except Exception:
            pass
    return keep


def _create_button(shelf_layout, icon_name):
    cmds.shelfButton(
        parent=shelf_layout,
        label=BUTTON_LABEL,
        annotation=BUTTON_ANN,
        image1=icon_name,   # image1 is the important shelf icon
        image=icon_name,
        command=_worldsnap_command(),
        sourceType="python",
    )


def _update_button(btn, icon_name):
    try:
        cmds.shelfButton(btn, e=True, label=BUTTON_LABEL, annotation=BUTTON_ANN)
        cmds.shelfButton(btn, e=True, image1=icon_name, image=icon_name)
        cmds.shelfButton(btn, e=True, command=_worldsnap_command(), sourceType="python")
    except Exception:
        pass


def _save_shelves():
    try:
        mel.eval("saveAllShelves $gShelfTopLevel;")
    except Exception:
        pass


def _do_install_no_guard():
    shelf = _ensure_shelf()
    icon = _ensure_icon_in_prefs()

    buttons = _find_worldsnap_buttons(shelf)
    keep = _dedupe_keep_first(buttons)

    if keep is None:
        _create_button(shelf, icon)
        buttons = _find_worldsnap_buttons(shelf)
        keep = buttons[0] if buttons else None
    else:
        _update_button(keep, icon)

    return keep, icon


def _post_fix_icon(btn, icon_name):
    """
    Run AFTER Maya is fully initialized: refresh cache and re-apply icon.
    This is the piece that removes the need for "run python manually".
    """
    _refresh_icon_cache_quiet()

    if btn and cmds.control(btn, exists=True):
        try:
            cmds.shelfButton(btn, e=True, image1=icon_name, image=icon_name)
        except Exception:
            pass

    _save_shelves()

    try:
        cmds.optionVar(intValue=(OPT_INSTALLED, 1))
    except Exception:
        pass


def install(max_retries=80):
    """
    Public entry point called from userSetup.mel.
    Waits for shelf UI, then installs, then does a second deferred pass to lock icon.
    """
    def _retry(n):
        if not _shelf_ui_ready():
            if n > 0:
                utils.executeDeferred(lambda: _retry(n - 1))
            return

        # If already installed, still do a quick icon refresh pass
        try:
            already = cmds.optionVar(exists=OPT_INSTALLED) and cmds.optionVar(q=OPT_INSTALLED) == 1
        except Exception:
            already = False

        if already:
            # Refresh cache and exit (keeps it cheap)
            utils.executeDeferred(lambda: _refresh_icon_cache_quiet())
            return

        btn, icon_name = _do_install_no_guard()

        # Critical: one more deferred tick AFTER install
        utils.executeDeferred(lambda: _post_fix_icon(btn, icon_name))

    utils.executeDeferred(lambda: _retry(int(max_retries)))