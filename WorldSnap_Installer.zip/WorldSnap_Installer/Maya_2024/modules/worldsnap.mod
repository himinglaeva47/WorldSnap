+ WorldSnap 1.0 ./WorldSnap
PYTHONPATH +:= scripts
MAYA_SCRIPT_PATH +:= scripts