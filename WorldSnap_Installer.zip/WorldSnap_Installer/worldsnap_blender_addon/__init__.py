bl_info = {
    "name": "WorldSnap",
    "author": "You",
    "version": (1, 0, 0),
    "blender": (4, 5, 0),
    "location": "View3D",
    "description": "WorldSnap tools",
    "category": "Object",
}

from .worldsnap_core import register, unregister