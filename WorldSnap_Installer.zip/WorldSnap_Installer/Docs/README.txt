WORLD SNAP — OFFICIAL DESCRIPTION
WorldSnap v1.0

Precision alignment for Maya & Blender

WorldSnap is a fast, artist-focused alignment tool that removes the need for manual positioning and scaling.
It allows you to snap characters, props, and environments together using real spatial logic instead of guesswork.

What it does

WorldSnap provides a one-click system for:

Snapping one object directly to another
Matching scale automatically using bounding box height
Aligning objects to the ground plane
Centering objects to the world origin
Pivot-based alignment
Optional rotation matching

All operations are designed to be predictable, consistent, and fast.

Why it exists

Positioning assets manually is slow, imprecise, and repetitive.
WorldSnap replaces that process with a reliable system that produces correct results instantly.

Built for real workflows

WorldSnap is designed for practical production use, including:

Character pipelines (multi-scale characters and scene alignment)
ZBrush ↔ Maya workflows
AI-generated meshes (Tripo, Trellis, etc.)
Environment assembly and layout
Kitbashing and asset placement

It is especially useful when working with assets that import at incorrect scale or position.

Core features
Object-to-object snapping (source → target)
Automatic height matching (bounding box based)
Ground to grid alignment
Center to origin
Pivot-to-pivot snapping
Optional rotation matching
Include/exclude scene objects
Non-destructive options (preserve history and transforms)
Supported software
Autodesk Maya (2024–2026)
Blender (4.5_5.0)

Philosophy

WorldSnap is built to remove friction from one of the most common tasks in 3D:

putting things exactly where they belong

Usage & distribution

This tool is free to use.

Please do not redistribute, resell, or repackage this tool.
If you would like to share it, link to the original release page.

Support

If you find WorldSnap useful, support is always appreciated.