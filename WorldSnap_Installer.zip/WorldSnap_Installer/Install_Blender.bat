@echo off
setlocal EnableExtensions

echo.
echo ===== WorldSnap Blender Installer =====
echo.

set "BASE_DIR=%~dp0"
set "BLENDER_DIR=%APPDATA%\Blender Foundation\Blender"

echo Source:
echo %BASE_DIR%
echo.
echo Blender user folder:
echo %BLENDER_DIR%
echo.

call :Install 4.5
call :Install 5.0

echo.
echo ===== Done =====
echo.
pause
exit /b

:Install
set "VER=%~1"
set "DST=%BLENDER_DIR%\%VER%\scripts\addons"

echo -----------------------------------
echo Blender %VER%
echo Destination: %DST%
echo -----------------------------------

if not exist "%BLENDER_DIR%\%VER%" (
    echo Blender %VER% not found. Skipping.
    echo.
    goto :eof
)

if not exist "%DST%" mkdir "%DST%"

if exist "%BASE_DIR%worldsnap_blender_addon" (
    xcopy "%BASE_DIR%worldsnap_blender_addon" "%DST%\worldsnap_blender_addon\" /E /I /Y
) else (
    echo ERROR: worldsnap_blender_addon folder not found beside installer.
)

if exist "%BASE_DIR%pyarmor_runtime_012073" (
    xcopy "%BASE_DIR%pyarmor_runtime_012073" "%DST%\pyarmor_runtime_012073\" /E /I /Y
) else (
    echo ERROR: pyarmor_runtime_012073 folder not found beside installer.
)

echo Blender %VER% install finished.
echo.
goto :eof